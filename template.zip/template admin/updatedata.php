<!doctype html>
<html lang="en">

<head>
  <title>Ulangan 1</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
</head>

<body class="dark-edition">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="black" data-image="./assets/img/sidebar-2.jpg">
      <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
      
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="javascript:void(0)">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./userprofile.php">
              <i class="material-icons">person</i>
              <p>User Profile</p>
            </a>
          </li>

          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">

          <!-- your content here -->
  <section>


  <form action="prosesupdate.php" method="post">

<?php
      include 'koneksi.php';
      $id=$_GET['id'];
      $query = mysqli_query($dbconnect, "SELECT * FROM kontak WHERE id = '$id' ");

      $tampil = mysqli_fetch_assoc($query);

?>
  <section>
            <section>
                 <section>
                      <div class="mb-3">
      <label for="id" class="form-label">id </label>
      <input type="text" readonly=" " class="form-control" id="id" name="id" value="<?php echo $tampil ['id']?>">
    </div>
    <div>
      <div class="mb-3">
        <label for="nama" class="form-label">nama </label>
        <input type="text" class="form-control" name="nama" id="nama" autocomplete="off" requid value="<?php echo $tampil ['nama']?>">
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email </label>
        <input type="text" class="form-control" id="email" name="email" required autocomplete="off" value="<?php echo $tampil ['email']?>">
      </div>
      <div class="mb-3">
        <label for="notelp" class="form-label">No.Telp </label>
        <input type="text" class="form-control" id="notelp" name="notelp" required autocomplete="off" value="<?php echo $tampil ['notelp']?>">
      </div>
      <div class="mb-3">
        <label for="pekerjaan" class="form-label">Pekerjaan </label>
        <input type="text" class="form-control" name="pekerjaan" id="pekerjaan" required autocomplete="off" value="<?php echo $tampil ['pekerjaan']?>">
      </div>
      <div class="mb-3">
      <button type="submit" name="inputdata" class="btn btn-primary" onclick="return confirm ('apakah anda yakin ingin merubah data tersebut ?')">ubah</button>
    </div>
  </section>
  </section>
  </section>
  </form>
  </section>
      </main>
    </div>
  </div>
        
        <button type="submit" name="inputdata" class="btn btn-primary" onclick="return confirm ('apakah anda yakin ingin mengirimkan data tersebut ? data tidak bisa diubah setelah data dikirim') ">Input Data</button>
      </form>
    </section>
      </main>
    </div>
  </div>


        </div>
      </div>
    </div>
  </div>
</body>
</html>