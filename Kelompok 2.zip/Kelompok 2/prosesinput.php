<?php

 include 'config.php';
 $nama= $_POST['nama'];
 $harga= $_POST['harga'];
 $foto= $_POST['foto'];
 $durasi= $_POST['durasi'];

  mysqli_query($dbconnect, "INSERT INTO tb_film VALUES (NULL, '$nama','$harga','$foto','$durasi')");
  header("location:index.php");

?>