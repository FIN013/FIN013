<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width= , initial-scale=1.0">
    <title>Web Film</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Henny+Penny&family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="shortcut icon" href="images/Logo.png">
</head>
<body>
<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
        <a href="index.php"><img src="images/logo.png" alt="Sobat Film" width="125px"></a>

        </div>
        <nav>
            <ul id="MenuItems">
                <a href="index.php"> <li>Home</li></a>
                <a href="about.php"><li>About</li></a>
                <a href="contacts.php"> <li>Kontak</li></a>
                <a href="logout.php"><li>Logout</li></a>
            </ul>
        </nav>
        </div>
       
<h2 class="title">Sobat Film</h2>
<!-------- featured categories -------->
<div class="categories">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <img src="images/1.jpg" alt="">

            </div>
            <div class="col-3">
                <img src="images/7.jpg" alt="">
            </div>
            <div class="col-3">
                <img src="images/3.jpg" alt="">
            </div>
        </div>
    </div>
   
</div>


<!------Slider------>

<!-------- featured products -------->
<div class="small-container">
<h2 class="title">Produk Unggulan</h2>
<!------Btn Tambah----->
<a href="input.php" class="btn">Tambah</a>
            </div>

<div class="row">
 
     


    <?php
include 'config.php';
$number = mysqli_query($dbconnect, "SELECT * FROM tb_film"  );
$no = 1;
while ($query = mysqli_fetch_array($number)) {
              
               

            ?>

         <div class="col-4">
                <img src="images/<?php echo $query['foto'] ?>" alt="">
        <h4><?php echo $query ['nama']?></h4>
        <div class="rating">
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star-o"></i>
        </div>
        <p><?php echo $query ['harga']?></p></a>
        <p><?php echo $query ['durasi']?></p>
        <a href="Edit.php?nama=<?php echo $query ['nama']?>" class="btn" >EDIT</a>
        <a href="proseshapus.php?nama=<?php echo $query ['nama']?>" class="btn" onclick ="return confirm ('apakah anda yakin ingin menghapus data? dengan nama <?php echo $query ['nama'] ?>')">HAPUS</a></td>


    </div>
       <?php
   }
       ?>
<!--------------- testimonial ------------->
<div class="testimonial">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>
                    Banyak hal baru yang saya ketahui tentang dunia dan komunitas, saya menjadi tertarik untuk mempelajarinya lebih lanjut!
                </p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <img src="images/user-1.png" alt="">
                <h3>Dian Reish</h3>

            </div>
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>
                    Seperti di Judul, Ini bukan tentang aku, kamu atau dia, Ini adalah Tentang Kita, Kita adalah Semangat Komunitas itu Sendiri!
                </p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <img src="images/user-2.png" alt="">
                <h3>Robert Banner</h3>
                
            </div>
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>
                    Barang yang ditawarkan sangat banyak dan bermacam-macam, saran saya anda harus mengkategorikannya dengan benar :)
                </p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <img src="images/user-3.png" alt="">
                <h3>Diana Jhonson</h3>
                
            </div>
        </div>
    </div>
</div>


<!--------------brands------------->
<div class="brands">
    <div class="small-container">
        <div class="row">
            <div class="col-5">
                <img src="images/logo-godrej.png" alt="">
            </div> 
            <div class="col-5">
                <img src="images/logo-oppo.png" alt="">
            </div> 
            <div class="col-5">
                <img src="images/logo-coca-cola.png" alt="">
            </div> 
            <div class="col-5">
                <img src="images/logo-paypal.png" alt="">
            </div> 
            <div class="col-5">
                <img src="images/logo-philips.png" alt="">
            </div> 
        </div>
    </div>
</div>

<!----------------footer----------------->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>Download Semua Aplikasi</h3>
                <p>Download Aplikasi untuk Android dan IOS Mobile Phone</p>
                <div class="app-logo">
                    <img src="images/play-store.png" alt="">
                    <img src="images/app-store.png" alt="">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="images/logo-white.png" alt="">
                <p>Temukan Tujuan Baru, Hal Baru dan Keinginan serta Harapan Baru</p>
            </div>
            <div class="footer-col-3">
                <h3>Link Serbaguna</h3>
              <ul>
                  <li>Kupon</li>
                  <li>Postingan Blog</li>
                  <li>Pengembalian</li>
                  <li>Komunitas</li>
              </ul>
            </div>
            <div class="footer-col-4">
                <h3>Ikuti Kita</h3>
              <ul>
                  <li>Facebook</li>
                  <li>Twitter</li>
                  <li>Instagram</li>
                  <li>Youtube</li>
              </ul>
            </div>
        </div>

<hr>
<p class="copyright">Copyright 2022 - Kelompok 2</p>

    </div>
</div>
<!--------------------js for toggle menu-------------------->
<script>
var MenuItems = document.getElementById("MenuItems");

MenuItems.style.maxHeight = "0px";

function menutoggle(){
    if(MenuItems.style.maxHeight == "0px")
    {
        MenuItems.style.maxHeight = "200px";
    }

    else
    {
        MenuItems.style.maxHeight = "0px";
    }
}


</script>

    
</body>
</html>