<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width= , initial-scale=1.0">
    <title>Web Film</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Henny+Penny&family=Poppins:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="shortcut icon" href="images/Logo.png">
</head>
<body>

<div class="header">
<div class="container">
    <div class="navbar">
        <div class="logo">
        <a href="index.php"><img src="images/logo.png" alt="Sobat Film" width="125px"></a>

        </div>
        <nav>
            <ul id="MenuItems">
                <a href="index.php"> <li>Home</li></a>
                <a href="about.php"><li>About</li></a>
                <a href="contacts.php"> <li>Kontak</li></a>
                <a href="logout.php"><li>Logout</li></a>
            </ul>
        </nav>
        </div>
       


<!------Slider------>
<div class="slider">
    <div class="isi-slider">
        <img src="images/banner.jpg" alt="Gambar 1">
        <img src="images/banner1.jpg" alt="Gambar 2">
        <img src="images/banner2.jpg" alt="Gambar 3">
    </div>
    
</div>
 <?php
            include 'config.php';
            $nama=$_GET['nama'];
            $query = mysqli_query($dbconnect,"SELECT * FROM tb_film WHERE nama = '$nama' ");
            $tampil = mysqli_fetch_assoc($query);


?>

<!-------- featured products -------->
<div class="small-container">
<h2 class="title">Edit Film</h2>
<!------Btn Tambah----->
 <div class="edit">
<form action="prosesedit.php" method="POST" class="form">
<h3 style="text-align:center;">
    Edit Film
</h3>
<input type="number" readonly="" id="id" name="id" required value="<?php echo $tampil ['id']?>">
<input type="text" id="nama" name="nama" required value="<?php echo $tampil ['nama']?>">
<input type="text" id ="harga" name="harga" required value="<?php echo $tampil ['harga']?>">
<input style="justify-content: left;" type="file" id ="foto" name="foto"required value="<?php echo $tampil ['foto']?>">
<input type="text" id ="durasi" name="durasi" placeholder="Harga" required value="<?php echo $tampil ['durasi']?>">
<button type="submit">Kirim</button>
</form>
    </div>



<!--------------- testimonial ------------->
<div class="testimonial">
    <div class="small-container">
        <div class="row">
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>
                    Banyak hal baru yang saya ketahui tentang dunia dan komunitas, saya menjadi tertarik untuk mempelajarinya lebih lanjut!
                </p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <img src="images/user-1.png" alt="">
                <h3>Dian Reish</h3>

            </div>
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>
                    Seperti di Judul, Ini bukan tentang aku, kamu atau dia, Ini adalah Tentang Kita, Kita adalah Semangat Komunitas itu Sendiri!
                </p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <img src="images/user-2.png" alt="">
                <h3>Robert Banner</h3>
                
            </div>
            <div class="col-3">
                <i class="fa fa-quote-left"></i>
                <p>
                    Barang yang ditawarkan sangat banyak dan bermacam-macam, saran saya anda harus mengkategorikannya dengan benar :)
                </p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <img src="images/user-3.png" alt="">
                <h3>Diana Jhonson</h3>
                
            </div>
        </div>
    </div>
</div>


<!--------------brands------------->
<div class="brands">
    <div class="small-container">
        <div class="row">
            <div class="col-5">
                <img src="images/logo-godrej.png" alt="">
            </div> 
            <div class="col-5">
                <img src="images/logo-oppo.png" alt="">
            </div> 
            <div class="col-5">
                <img src="images/logo-coca-cola.png" alt="">
            </div> 
            <div class="col-5">
                <img src="images/logo-paypal.png" alt="">
            </div> 
            <div class="col-5">
                <img src="images/logo-philips.png" alt="">
            </div> 
        </div>
    </div>
</div>

<!----------------footer----------------->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>Download Semua Aplikasi</h3>
                <p>Download Aplikasi untuk Android dan IOS Mobile Phone</p>
                <div class="app-logo">
                    <img src="images/play-store.png" alt="">
                    <img src="images/app-store.png" alt="">
                </div>
            </div>
            <div class="footer-col-2">
                <img src="images/logo-white.png" alt="">
                <p>Temukan Tujuan Baru, Hal Baru dan Keinginan serta Harapan Baru</p>
            </div>
            <div class="footer-col-3">
                <h3>Link Serbaguna</h3>
              <ul>
                  <li>Kupon</li>
                  <li>Postingan Blog</li>
                  <li>Pengembalian</li>
                  <li>Komunitas</li>
              </ul>
            </div>
            <div class="footer-col-4">
                <h3>Ikuti Kita</h3>
              <ul>
                  <li>Facebook</li>
                  <li>Twitter</li>
                  <li>Instagram</li>
                  <li>Youtube</li>
              </ul>
            </div>
        </div>

<hr>
<p class="copyright">Copyright 2022 - Kelompok 2</p>

    </div>
</div>
<!--------------------js for toggle menu-------------------->
<script>
var MenuItems = document.getElementById("MenuItems");

MenuItems.style.maxHeight = "0px";

function menutoggle(){
    if(MenuItems.style.maxHeight == "0px")
    {
        MenuItems.style.maxHeight = "200px";
    }

    else
    {
        MenuItems.style.maxHeight = "0px";
    }
}


</script>

    
</body>
</html>